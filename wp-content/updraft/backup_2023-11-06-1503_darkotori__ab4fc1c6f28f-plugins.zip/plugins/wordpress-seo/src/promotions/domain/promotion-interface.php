<?php

namespace Yoast\WP\SEO\Promotions\Domain;

/**
 * Interface for a Promotion.
 */
interface Promotion_Interface {}
