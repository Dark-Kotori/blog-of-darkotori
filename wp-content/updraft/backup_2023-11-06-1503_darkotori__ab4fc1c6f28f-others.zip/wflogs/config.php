<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:7:{s:9:"wafStatus";s:13:"learning-mode";s:30:"learningModeGracePeriodEnabled";i:1;s:23:"learningModeGracePeriod";i:1699887698;s:7:"authKey";s:64:"pb7RTZ;T>X.S^0v9<0H!Z_j5GEy](k3>#Iku_r)EY5<)SuF%0(TEQ0^P52)[^S`I";s:7:"version";s:5:"1.1.0";s:11:"wafDisabled";b:0;s:13:"attackDataKey";i:2787;}