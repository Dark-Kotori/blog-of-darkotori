<?php


namespace ExerciseBook\Flysystem\ImageX\Exception;


use RuntimeException;

class ImageXException extends RuntimeException
{

}