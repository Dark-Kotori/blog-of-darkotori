<?php


namespace ExerciseBook\Flysystem\ImageX;


class Config
{

}