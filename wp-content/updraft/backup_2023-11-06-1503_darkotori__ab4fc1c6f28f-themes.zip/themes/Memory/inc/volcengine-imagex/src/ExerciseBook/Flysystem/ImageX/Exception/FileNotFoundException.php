<?php


namespace ExerciseBook\Flysystem\ImageX\Exception;



class FileNotFoundException extends FilesystemException
{


}