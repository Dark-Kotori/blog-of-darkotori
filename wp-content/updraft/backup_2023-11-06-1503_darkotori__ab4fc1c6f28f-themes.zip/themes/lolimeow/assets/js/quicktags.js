
		QTags.addButton( 'blockquote2', '引用1', '[blockquote1 name=\'签名\']内容[/blockquote1]','' );
		QTags.addButton( 'blockquote3', '引用2', '[blockquote2 name=\'签名\']内容[/blockquote2]','' );
		QTags.addButton( 'H2', 'H2', '<h2 class="h-title">内容</h2>','' );
		QTags.addButton( 'H2', 'H2标题', '<h2 class="h-title">内容</h2>','' );
		QTags.addButton( 'H2', 'H2标题', '<h2 class="h-title">内容</h2>','' );
		QTags.addButton( 'H3', 'H3标题', '<h3 class="h-title">内容</h3>','' );
		QTags.addButton( 'H4', 'H4标题', '<h4>内容</h4>','' );
		QTags.addButton( 'codepre', '代码高亮', '<pre class="prettyprint linenums\">代码</pre>','' );
		QTags.addButton( 'nextpage', '分页', '<!--nextpage--\>','' );
		QTags.addButton( 'H2pen', 'H2毛笔标', '<h2 class="section-title"><span><i class="fa fa-paint-brush"></i>文字</span></h2>', '','','H2pen' ); 
		QTags.addButton( 'H2set', 'H2设置标', '<h2 class="section-title"><span><i class="fa fa-gear"></i>文字</span></h2>', '','','H2set' ); 
		QTags.addButton( 'H2download', 'H2下载标', '<h2 class="section-title"><span><i class="fa fa-cloud-download"></i>文字</span></h2>', '','','H2download' ); 
		QTags.addButton( 'H2wechat', 'H2微信标', '<h2 class="section-title"><span><i class="fa fa-wechat"></i>文字</span></h2>', '','','H2wechat' ); 
		QTags.addButton( 'H2mht', 'H2QQ企鹅标', '<h2 class="section-title"><span><i class="fa fa-qq"></i>文字</span></h2>', '','','H2mht' );
		QTags.addButton( 'downloadbtn', '下载按钮', '<a href="链接地址" rel="noopener" target="_blank" class="download_btn" data-bs-toggle="tooltip" data-bs-placement="top" title="该资源来源于网络如有侵权,请联系删除.">下载按钮</a>', '','','downloadbtn' );
		QTags.addButton( 'linksbtn', '链接按钮', '<a href="链接地址" rel="noopener" target="_blank" class="links_btn" >链接按钮</a>', '','','linksbtn' );
		QTags.addButton( 'flybtn', '飞来模块', '<div class="link-title wow rollIn">内容段</div>', '','','flybtn' );
		QTags.addButton( 'ollist', 'OL列表', '<ul class="ol"><ol>ol内容段</ol></ul>', '','','ollist' );
		QTags.addButton( 'audio', '音频', '[audio link=\'音频链接\'][/audio]', '','','audio' ); 
		QTags.addButton( 'video', '视频', '[video link=\'视频链接\'][/video]', '','','video' ); 
		QTags.addButton( 'userreading1', '会员查看模式一', '[userreading]', '隐藏内容[/userreading]','','userreading1' );  
		QTags.addButton( 'userreading2', '会员查看模式二', '[userreading notice="未登录时候显示的内容"]', '隐藏内容[/userreading]','','userreading2' ); 
		QTags.addButton( 'pwd_protected_post', '文章密码保护', '[pwd_protected_post key="保护密码"]文章密码保护内容','[/pwd_protected_post]' );
		QTags.addButton( 'downloadbox', '下载框', '<div class="post-download-box fontsom mt-2 mb-5">\n<h3>下载信息</h3>\n<ul class="infobox">\n<li class="title"><i class="fa fa-bars"></i> 下载地址1:<span><a href="https://www.boxmoe.com" target="_blank" rel="noopener">点击下载</a></span><small>说明</small> </li>\n</ul>\n<span class="sya">部分资源来源于网络如有侵权,请联系删除</span>\n</div>', '','','downloadbox' );		
    