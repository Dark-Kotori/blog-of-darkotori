<?php get_header(); ?>
        <div class="container">
          <div class="section-head">
            <span>404 not found</span></div>
        </div>
        <div class="boxmoe-blog-content">
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
			    <div class="alert alert-warning text-center" role="alert">
			    <span class="alert-icon"><i class="fa fa-bell"></i></span>
			    <span class="alert-text"><strong>哦豁！😂</strong> 你访问的页面不存在勒！</span>
			    </div>
              </div>
            </div>
          </div>
        </div>
<?php get_footer(); ?>

